// src/main/java/com/example/notes/FlightTypeController.java
package com.example.notes;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api")
@CrossOrigin // jeśli testujesz z emulatora/urządzenia
public class FlightTypeController {

    private final JdbcTemplate jdbc;

    public FlightTypeController(JdbcTemplate jdbc) {
        this.jdbc = jdbc;
    }

    // Lista typów lotu
    @GetMapping("/typ_lotu")
    public List<Map<String, Object>> listFlightTypes() {
        return jdbc.queryForList(
                // dopasuj nazwy kolumn; jeśli masz np. id_typu – zrób alias jak poniżej
                "SELECT id_typ AS id_typ, nazwa FROM typ_lotu ORDER BY nazwa"
        );
    }

    // (opcjonalnie) pojedynczy typ
    @GetMapping("/typ_lotu/{id}")
    public Map<String, Object> getFlightType(@PathVariable int id) {
        return jdbc.queryForMap(
                "SELECT id_typ AS id_typ, nazwa FROM typ_lotu WHERE id_typ = ?",
                id
        );
    }
}
