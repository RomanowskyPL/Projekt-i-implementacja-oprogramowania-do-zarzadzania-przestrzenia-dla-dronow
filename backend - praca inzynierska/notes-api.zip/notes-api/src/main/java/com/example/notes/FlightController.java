package com.example.notes;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/lot")
@CrossOrigin(origins = "*")
public class FlightController {

    private final JdbcTemplate jdbc;

    public FlightController(JdbcTemplate jdbc) {
        this.jdbc = jdbc;
    }

    @GetMapping
    public List<Map<String, Object>> listFlights() {
        String sql = """
        SELECT l.id_lotu,
               l.id_trasy,
               t.nazwa AS nazwa_trasy,
               l.czas_startu,
               l.czas_konca,
               COALESCE(l.rzeczywisty_czas_s,
                        EXTRACT(EPOCH FROM (l.czas_konca - l.czas_startu)))::int AS czas_trwania_s,
               COALESCE(o.imie || ' ' || o.nazwisko, '') AS operator,
               l.status
        FROM public.lot l
        LEFT JOIN public.trasy    t ON t.id_trasy     = l.id_trasy
        LEFT JOIN public.operator o ON o.id_operatora = l.id_operatora
        ORDER BY l.czas_startu DESC NULLS LAST
    """;
        return jdbc.queryForList(sql);
    }

    @GetMapping("/{id}")
    public Map<String, Object> flightDetail(@PathVariable int id) {
        String sql = """
        SELECT
            l.id_lotu, l.id_trasy, l.czas_startu, l.czas_konca, l.status,
            l.rzeczywista_dlugosc_lotu_m,
            COALESCE(l.rzeczywisty_czas_s,
                     EXTRACT(EPOCH FROM (l.czas_konca - l.czas_startu)))::int AS czas_trwania_s,

            t.nazwa  AS nazwa_trasy,
            t.opis   AS opis_trasy,

            o.id_operatora,
            o.imie, o.nazwisko, o.e_mail,

            ed.id_drona,
            ed.numer_seryjny,
            ed.status AS status_drona,

            md.producent,
            md.nazwa_modelu,
            md.klasa_drona,
            md.masa_g,
            md.zasieg_m,
            md.predkosc_m_s,

            tl.id_typ        AS id_typu_lotu,
            tl.nazwa         AS typ_lotu,
            tl.opis          AS opis_typu,
            tl.metadane      AS metadane_typu
        FROM public.lot l
        LEFT JOIN public.trasy            t  ON t.id_trasy     = l.id_trasy
        LEFT JOIN public.operator         o  ON o.id_operatora = l.id_operatora
        LEFT JOIN public.egzemplarz_drona ed ON ed.id_drona    = l.id_drona
        LEFT JOIN public.model_drona      md ON md.id_modelu   = ed.id_modelu
        LEFT JOIN public.typ_lotu         tl ON tl.id_typ      = l.id_typ
        
        WHERE l.id_lotu = ?
    """;
        return jdbc.queryForMap(sql, id);
    }

    public List<Map<String,Object>> flightRoutePoints(@PathVariable int id) {
        String sql = """
        SELECT
            tp.kolejnosc,
            ST_Y(tp.wspolrzedne::geometry) AS lat,
            ST_X(tp.wspolrzedne::geometry) AS lon,
            tp.wysokosc_m,
            COALESCE(tp.opis,'') AS opis
        FROM public.trasy_punkty tp
        JOIN public.lot l ON l.id_trasy = tp.id_trasy
        WHERE l.id_lotu = ?
        ORDER BY tp.kolejnosc
    """;
        return jdbc.queryForList(sql, id);
    }
}