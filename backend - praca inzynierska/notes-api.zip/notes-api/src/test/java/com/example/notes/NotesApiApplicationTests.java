package com.example.notes;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NotesApiApplicationTests {

    @Test
    void contextLoads() {
    }

}
