package pl.twoja.apka.model

data class DroneInstanceItem(
    val id: Int,
    val status: String?,
    val numerSeryjny: String?,
    val dataZakupu: String?
)
